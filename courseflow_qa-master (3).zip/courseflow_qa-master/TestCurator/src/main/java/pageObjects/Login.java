package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Login {

	@FindBy(id="username")
	public static WebElement loginusername;
	@FindBy(id="password")
	public static WebElement loginpwd;
	@FindBy(id="_submit")
	public static WebElement loginsubmitbtn;
	
	@FindBy(xpath="//nav[@id='sidenavAccordion']/div/div/div/div/p")
	public static WebElement username;
	
	@FindBy(xpath="//*[@id='container']/div/div/div")
	public static WebElement validationmessage;
	
	@FindBy(partialLinkText="Forgot your password?")
	public static WebElement forgotpasswordlink;
	
	@FindBy(id="username")
	public static WebElement forgotemail;
	
	@FindBy(xpath="//button/i")
	public static WebElement forgotpwdsubmitbtn;
		 
	@FindBy(partialLinkText="Return to Log In")
	public static WebElement returntologinlink;
	
	
}
