package pageObjects;

//import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CourseSession {
	
	@FindBy(xpath = "//div[contains(text(),'Course Sessions')]")
	public static WebElement CourseSessionlink;

	@FindBy(xpath = "//a[contains(text(),'Course Master')]")
	public static WebElement CourseMasterlink;
	
	@FindBy(xpath = "//i[contains(@class,'e-LC-text')]")
	public static WebElement CourseTextlink;
	
	@FindBy(xpath = "//i[contains(@class,'e-LC-image')]")
	public static WebElement CourseImageIcon;
	
	@FindBy(id = "learning_object_name")
	public static WebElement CourseTitlelink;
	
	@FindBy(id = "file-picker-btn")
	public static WebElement ImageUploadbtn;
	
	@FindBy(id = "file-picker")
	public static WebElement ImageUploadlink;
	
	
	@FindBy(xpath = "//iframe[contains(@class,'cke_wysiwyg_frame')]")
	public static WebElement iframebody;
	
	@FindBy(xpath = "//body[contains(@class,'cke_editable_themed')]/p")
	public static WebElement CourseBodyText;
	
	@FindBy(xpath = "//button[@id='saveBtn']")
	public static WebElement CourseSaveBtn;
	
	@FindBy(xpath="//label/span[contains(text(),'Library')]")
    public static WebElement Libraryspan;
	
	@FindBy(id="librarysearch_name")
	public static WebElement LibrarySearchIcon;
	
	@FindBy(xpath = "//tbody[@id='library-list-table']/tr/td/b")
	public static WebElement LibraryListItems;
	
	@FindBy(xpath = "//li[contains(@class,'bp-hide-lg-xl-up')]//a[contains(@class,'init-tooltip')]")
	public static WebElement CourseLevelPublishBtn;
	
	@FindBy(id = "publishDropBtn")
	public static WebElement CourseLevelPublishDropBtn;
	
	@FindBy(xpath = "//button[@id = 'pub-init-btn'][text()='Yes']")
	public static WebElement PublishLessionYesconfirmationBtn;
	
	@FindBy(xpath = "//div[@id='pub-success']//a[contains(text(),'Done')]")
	public static WebElement PublishSuccssDoneBtn;
	
	@FindBy(xpath = "//div[@id='timeline-mainmenu']/div[1]")
	public static WebElement lesconfirmationmsg;	
	
	@FindBy (xpath="//div[contains(text(),'Course Sessions')]")
    public static WebElement coursesessionslink;
	
	@FindBy (xpath="//div[@id='modal-new-userpermission']/following-sibling::div/div[2]/div/div/a[contains(text(),'Add Session')]/i")
	public static WebElement addsessionbtn;

	@FindBy (xpath="//*[@id='layoutSidenav_content']/main/div[3]/div/div/div[3]/div[1]/div[2]/div/div/a")
	public static WebElement addsessionupdatecoursebtn;
	
	@FindBy (id="session_name")
	public static WebElement sessionname;
	
	@FindBy (id="session_type")
	public static WebElement sessiontype;
	
	@FindBy (id="session_description")
	public static WebElement sessiondescription;
	
	@FindBy (id="btnSessionSubmit")
	public static WebElement createsessionbtn;

	@FindBy(xpath = "//*[@id='layoutSidenav_content']/main/div[1]")
	public static WebElement Confirmationmsg;
	
	@FindBy(xpath ="//a[contains(@class,'panel-session-count')]/span")
	public static WebElement coursesessioncountlink;
	
	@FindBy(id="sessionsearch_name")
	public static WebElement sessionsearchbox;
	
	@FindBy(xpath="//tbody/tr/td")
	public static WebElement sessionresulttable;
	
	@FindBy(xpath="//a/p[contains(text(),'Courses')]")
	public static WebElement courselink;
	
	@FindBy(xpath = "//a[contains(text(),'Create')]")
	public static WebElement CreateCourselink;
	
	}
