package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Communication_Announcement {
	
	@FindBy(xpath="//a[@data-target='#communicationitems']")
	public static WebElement Communicationlink;
	
	@FindBy(xpath="//a[@id='homemenu_announcements']/p")
	public static WebElement Announcementlink;
	
	@FindBy (xpath="//a[contains(text(),'New Announcement')]")
	public static WebElement NewAnnouncementBtn;
	
	@FindBy(id="anouncement_name")
	public static WebElement Announcement_title;
	
	@FindBy(id="anouncement_university_id")
	public static WebElement OrganizationDropDown;
	
	@FindBy(id="anouncement_begin_date")
	public static WebElement Announcement_begin_date;
	        
	@FindBy(id="anouncement_end_date")
	public static WebElement Announcement_end_date;
	
	@FindBy(xpath = "//iframe[contains(@class,'cke_wysiwyg_frame')]")
	public static WebElement iframebody;
	
	@FindBy(xpath = "//body[contains(@class,'cke_editable_themed')]/p")
	public static WebElement CourseBodyText;
	
	@FindBy(id="btnAnnouncementSubmit")
	public static WebElement AnnouncementCreateBtn;
	
	@FindBy(xpath = "//*[@id='layoutSidenav_content']/main/div[1]")
	public static WebElement Confirmationmsg;
	
	@FindBy(xpath="//a[contains(@class,'nav-top-menu-icon')]/i")
	public static WebElement homeiconbtn;

}
