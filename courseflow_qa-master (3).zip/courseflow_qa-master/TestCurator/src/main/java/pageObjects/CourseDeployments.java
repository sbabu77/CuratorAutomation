package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CourseDeployments {
	
	
//	@FindBy(xpath="//select[@id='new_deploy_course']/following-sibling::Span/span/span")
//	public static WebElement CourseDeploymentDropDown;
	
	@FindBy(id="active_deployment_course")
	public static WebElement CourseDeploymentDropDown;
	
	@FindBy(id="active_deployment_session_id")
	public static WebElement CourseSessionDropDown;
	
	@FindBy(id="active_deployment_lmsconfig_id")
	public static WebElement CourseConnectorDropDown;
	
	@FindBy(id="active_deployment_lmsconfig_id")
	public static WebElement LMSCourseIdDropDown;
	
	@FindBy(id="btnCourseSubmit")
	public static WebElement CourseDeploymentCreatebtn;
	
	@FindBy (id="coursesearch_name")
	public static WebElement CourseSearchBox;
	
	@FindBy (xpath="//*[@id='active-deploy-list']/tbody/tr/td[6]/div")
	public static WebElement StatusBtn;
	
	@FindBy (xpath="//*[@id='active-deploy-list']/tbody/tr/td[7]/div/button/i")
	public static WebElement ModifyBtn;
	
	@FindBy (xpath="//*[@id='active-deploy-list']/tbody/tr[1]/td[7]/div/div/a[3]")
	public static WebElement DeployBtn;
	
	@FindBy (xpath="//div//button[.='Deploy Now']")
	public static WebElement DeployNowBtn;
	
	@FindBy (id="btn-syncnow")
	public static WebElement DeploysubBtn;
	
	@FindBy (xpath="//div//button[.='OK']")
	public static WebElement OKConfirmationBtn;
	
	@FindBy (xpath="//*[@id='active-deploy-list']/tbody/tr/td[5]/span")
	public static WebElement LastDeployedDate;
	
	
	
	
	}
