package stepDefinition;

import java.awt.Robot;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

import stepDefinition.NewOrganizationCreation;

public class NewLibrary extends BaseClass{


	@When("^user navigate into library screen$")
	public void user_navigate_into_library_screen() throws Throwable {

		PageFactory.initElements(driver, pageObjects.Library.class);
//		wait(pageObjects.Library.CreateCourselink);
		pageObjects.Library.CreateCourselink.click();
//		wait(pageObjects.Library.LibrariesMainMenu);
		pageObjects.Library.LibrariesMainMenu.click();
		wait(pageObjects.Library.MyLibrariesMenu);
		pageObjects.Library.MyLibrariesMenu.click();



	}

	@When("^Click the Add New Resources button and upload the below \"([^\"]*)\" under university library$")
	public void click_the_Add_New_Resources_button_and_upload_the_below_under_university_library(String resourcename) throws Throwable {
	
		PageFactory.initElements(driver, pageObjects.Library.class);
			   String path = System.getProperty("user.dir");

		wait(pageObjects.Library.AddNewResourceBtn);	   
		pageObjects.Library.AddNewResourceBtn.click();
		Thread.sleep(2000);
//		wait(pageObjects.Library.libUploadlink);
			pageObjects.Library.libUploadlink.sendKeys(path+ "\\TestData\\" + resourcename);
			Thread.sleep(8000);

//		pageObjects.Library.FileUploadBtn.click();
//		Thread.sleep(2000);
		// code for file upload
//		Robot robo = new Robot();
//		StringSelection str = new StringSelection (resourcename);
//		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);

//		robo.keyPress(KeyEvent.VK_CONTROL);
//		robo.keyPress(KeyEvent.VK_V);

//		robo.keyRelease(KeyEvent.VK_CONTROL);
//		robo.keyRelease(KeyEvent.VK_V);

//		robo.keyPress(KeyEvent.VK_ENTER);
//		robo.keyRelease(KeyEvent.VK_ENTER);

	wait(pageObjects.Library.UploadLibraryBtn);		
	pageObjects.Library.UploadLibraryBtn.click();
	}



	@Then("^owner user able to add new resources under library$")
	public void owner_user_able_to_add_new_resources_under_library() throws Throwable {

		//	String alertmsg = pageObjects.Organization.Confirmationmsg.getText();
		String alertmsg = pageObjects.Library.Confirmationmsg.getText();
		Assert.assertTrue(alertmsg.contains("The content was updated"));
		System.out.println("Resource was created into My Library Successfully");
	//	logout();

	}
}
