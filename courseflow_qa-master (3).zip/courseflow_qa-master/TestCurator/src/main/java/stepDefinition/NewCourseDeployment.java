package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class NewCourseDeployment extends BaseClass{
	String crsName;
	String crsConnector;
	String crsSession;
	String crsLMSID;
	@When("^user click the Course Deployments navigation panel and click New Course Deployment button$")
	public void user_click_the_Course_Deployments_navigation_panel_and_click_New_Course_Deployment_button() throws Throwable {

		PageFactory.initElements(driver, pageObjects.CourseDeployments.class);
		wait(pageObjects.Deploy.CourseDeploymentNavLink);
		pageObjects.Deploy.CourseDeploymentNavLink.click();
		wait(pageObjects.Deploy.NewCourseDeploymentBtn);
		pageObjects.Deploy.NewCourseDeploymentBtn.click();
		
	}
	
	@When("^select Course Name, Session Name, Course Connector and LMS Course ID from the respective drop downs$")
	public void select_Course_Name_Session_Name_Course_Connector_and_LMS_Course_ID_from_the_respective_drop_downs(DataTable depTable) throws Throwable {
	
		List<List<String>> deployTable = depTable.raw();
		crsName = deployTable.get(1).get(0);
		crsSession = deployTable.get(1).get(1);
		crsConnector = deployTable.get(1).get(2);
		crsLMSID = deployTable.get(1).get(3);
		
		Thread.sleep(3000);
		PageFactory.initElements(driver, pageObjects.CourseDeployments.class);
		wait(pageObjects.CourseDeployments.CourseDeploymentDropDown);
	//	System.out.println(crsName);
		pageObjects.CourseDeployments.CourseDeploymentDropDown.sendKeys(crsName);
		wait(pageObjects.CourseDeployments.CourseSessionDropDown);
//		System.out.println(crsSession);
		pageObjects.CourseDeployments.CourseSessionDropDown.sendKeys(crsSession);
		wait(pageObjects.CourseDeployments.CourseConnectorDropDown);
//		System.out.println(crsConnector);
		pageObjects.CourseDeployments.CourseConnectorDropDown.sendKeys(crsConnector);
		wait(pageObjects.CourseDeployments.LMSCourseIdDropDown);
//		System.out.println(crsLMSID);
		pageObjects.CourseDeployments.LMSCourseIdDropDown.sendKeys(crsLMSID);
		
		
	}
	
	@When("^click the create button$")
	public void click_the_create_button() throws Throwable {
		PageFactory.initElements(driver, pageObjects.CourseDeployments.class);
//		Thread.sleep(1000);
		wait(pageObjects.CourseDeployments.CourseDeploymentCreatebtn);
		pageObjects.CourseDeployments.CourseDeploymentCreatebtn.click();
	}
	
	@Then("^Course deployment should be created$")
	public void course_deployment_should_be_created() throws Throwable {
	  
		Thread.sleep(1000);
		String alertmsg = pageObjects.Organization.Confirmationmsg.getText();
	//	Assert.assertTrue(alertmsg.contains("Course Deployment was created"));
  
		System.out.println("'" + crsName + "' deployment was created Successfully");
		
//		Thread.sleep(5000);
//		tearDown();
	}


}
