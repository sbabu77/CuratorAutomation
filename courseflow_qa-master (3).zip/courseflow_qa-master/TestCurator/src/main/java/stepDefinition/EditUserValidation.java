package stepDefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import appUtils.BaseClass;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class EditUserValidation extends BaseClass {
	
	String cname = null;
	String cdesc = null;
	String uniwebsite = null;
	String uniacronym = null;
	String unilanguage = null;
	
	
	 @When("^user click the Organization link and edit WebSite, Acronym and Lanugage in the institution page$")
	  public void user_click_the_Organization_link_and_edit_WebSite_Acronym_and_Lanugage_in_the_institution_page(DataTable orgtable1) throws Throwable {
	  
			
			List<List<String>> orgdata = orgtable1.raw();
			uniwebsite = orgdata.get(1).get(0);
			uniacronym = orgdata.get(1).get(1);
			unilanguage = orgdata.get(1).get(2);
		   
			PageFactory.initElements(driver, pageObjects.Organization.class);
					
			wait(pageObjects.Organization.MyOranizantionmainTab);
			pageObjects.Organization.MyOranizantionmainTab.click();
			wait(pageObjects.Organization.MyOranizantionSubTab);
			pageObjects.Organization.MyOranizantionSubTab.click();
			
		  	pageObjects.Organization.unieditbtn.click();
			
			  pageObjects.Organization.orgWebsite.clear();
			  pageObjects.Organization.orgWebsite.sendKeys(uniwebsite);
			  pageObjects.Organization.orgAcronym.clear();
			  pageObjects.Organization.orgAcronym.sendKeys(uniacronym);
			  wait(pageObjects.Organization.orgDefaultContentLanguage);
			  pageObjects.Organization.orgDefaultContentLanguage.click();
			  pageObjects.Organization.orgDefaultContentLanguage.sendKeys(unilanguage);
			
			  pageObjects.Organization.uniupdatebtn.click();
			
	  }
	
	@When("^user navigate to create screen and click the edit option in the course$")
	public void user_navigate_to_create_screen_and_click_the_edit_option_in_the_course() throws Throwable {
	  
		PageFactory.initElements(driver, pageObjects.CreateCourse.class);
		wait(pageObjects.CreateCourse.CreateCourselink);
		pageObjects.CreateCourse.CreateCourselink.click();
		pageObjects.CreateCourse.CourseMoreBtn.click();
		pageObjects.CreateCourse.CourseEditBtn.click();
		
	}

	@When("^update course name and description in course screen$")
	public void update_course_name_and_description_in_course_screen(DataTable coursetable) throws Throwable {
		
		List<List<String>> crsdata = coursetable.raw();
		cname = crsdata.get(1).get(0);
		cdesc = crsdata.get(1).get(1);	
		
		wait(pageObjects.CreateCourse.CourseName);
		pageObjects.CreateCourse.CourseName.clear();
		pageObjects.CreateCourse.CourseName.sendKeys(cname);
		pageObjects.CreateCourse.CourseDesc.clear();
		pageObjects.CreateCourse.CourseDesc.sendKeys(cdesc);
		
	}

	@When("^click the update button$")
	public void click_the_update_button() throws Throwable {
		
		pageObjects.CreateCourse.CourseUpdateBtn.click();
	 
	}

	@When("^user click Create link and course session from course and click session link$")
	public void user_click_Create_link_and_course_session_from_course_and_click_session_link() throws Throwable {
	  
		PageFactory.initElements(driver, pageObjects.CourseSession.class);
		pageObjects.CourseSession.CreateCourselink.click();
		pageObjects.CourseSession.coursesessioncountlink.click();
		pageObjects.CourseSession.CourseMasterlink.click();
		
	}


	@Then("^details should be updated successfully$")
	public void details_should_be_updated_successfully() throws Throwable {
		
		String alertmsg = pageObjects.CreateCourse.Confirmationmsg.getText();
		Assert.assertTrue(alertmsg.contains("The course was updated"));
		System.out.println("'" + cname + "' Course was Updated Successfully");
		
	}
	
	@Then("^user should able to update organization details successfully$")
	public void user_should_able_to_update_organization_details_successfully() throws Throwable {
			String alertmsg = pageObjects.Organization.Confirmationmsg.getText();
			Assert.assertTrue(alertmsg.contains("The university was updated"));
			System.out.println("University was updated Successfully");
	}

}
